[
    {
      "nameItem": "Hạnh phúc ",
      "price": "99000",
      "type": "tiengviet",
      "describe":"Một trong những đặc trưng của người Nhật chính là lối sống tối giản. Lối sống này đã chứng minh hiệu quả hướng tới sự giải thoát khỏi những ám ảnh về cả vật chất lẫn tinh thần. Với quyển sách hay về hạnh phúc này, bạn sẽ biết thêm về trải nghiệm của Michelle người phụ nữ có một gia đình đông đúc với cuộc sống thường xuyên phải dịch chuyển...",
      "image": "https://vnwriter.net/wp-content/uploads/2018/05/sach-hanh-phuc-la-khong-cho-doi-188x300.jpg",
      "id": "1"
    },
    {
      "nameItem": "Hồi kí",
      "price": "100000",
      "type": "tiengviet",
      "describe":"Kalanithi rất yêu thích văn chương nên câu chuyện của anh đã được thuật lại theo một phong cách mượt mà, dung dị và đầy cảm xúc. Độc giả cũng được hiểu thêm về triết lý sống, triết lý nghề y của Kalanithi, thông qua ký ức về những ngày anh còn là sinh viên, rồi thực tập, cho đến khi chính thức hành nghề phẫu thuật thần kinh...",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/224/doi-giay-truot-bang.jpg",
      "id": "2"
    },
    {
      "nameItem": "Đồi tuyết",
      "price": "120000",
      "type": "tiengviet",
      "describe":"Bên Rặng Tuyết Sơn là quyển sách mới trong bộ sách khoa học tâm linh nổi tiếng của dịch giả Nguyên Phong. Khơi nguồn từ vùng núi Himalaya xa xôi và vùng đồng bằng Ấn Độ, Bên Rặng Tuyết Sơn mang đến cho bạn đọc những sự thật vĩ đại về tâm linh và vai trò của việc làm chủ tâm linh cũng như làm chủ số phận. Tác phẩm còn khơi dậy những giá trị cao đẹp như: Tính trung thực, trái tim bao dung, lòng trắc ẩn, sự thông thái, lòng tín ngưỡng và tình yêu bao la...",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/224/wham-george-va-toi-hoi-ki.jpg",
      "id": "3"
    },
    {
      "nameItem": "Đôi  tennis",
      "price": "119000",
      "type": "tiengviet",
      "describe":"Câu chuyện bắt đầu từ việc Satyakam đến thung lũng Saraswati để tầm sư học đạo. Nhưng không ngờ rằng, khi đến đây, thì vị đạo sư già đã chờ anh rồi, không những thế, ông còn nói đúng tên anh và biết anh đến gặp ông để làm gì dù rằng anh chưa hề xưng tên cũng như chưa nói mục đích của mình đến đây...",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/224/doi-giay-tennis.jpg",
      "id": "4"
    },
    {
      "nameItem": "Cơn ác mộng",
      "price": "129000",
      "type": "tiengviet",
      "describe":"Dài học đầu tiên của Satyakam là quên đi thời gian. Việc này nghe qua tưởng chừng như đơn giản nhưng khi bắt đầu thực hiện lại không đơn giản chút nào. Cũng như việc lắng nghe những âm thanh của vũ trụ như tiếng lá rơi, tiếng gió thổi, tiếng nước reo cũng không dễ dàng thực hiện nếu trong lòng ta vẫn còn nhiều tạp âm...",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/224/nhung-nguoi-phu-nu-be-nho.jpg",
      "id": "5"
    },
    {
      "nameItem": "Đôi chân bé nhỏ",
      "price": "149000",
      "type": "tiengviet",
      "describe":"Trên nền câu chuyện cuộc đời của nhân vật có thật, triệu phú Alan Havey, Hoa sen trên tuyết gieo vào độc giả nhiều điều phải nghĩ. Xuất thân từ một gia đình nghèo ở Mỹ và hiểu rõ giá trị của đồng tiền. Alan Havey đã nỗ lực rất nhiều để làm việc, học tập và đạt được những thành công nhất định: biệt thự lộng lẫy bên bờ Michigan, căn nhà nghỉ mát trên núi Mt Vernon, du thuyền, tài khoản kếch xù trong ngân hàng và một cô vợ đẹp như diễn viên điện ảnh…",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/224/nhung-nguoi-phu-nu-be-nho.jpg",
      "id": "6"
    },
    {
      "nameItem": "Hết yêu",
      "price": "96000",
      "type": "tiengviet",
      "describe":"Tại sao ông lại phải gánh chịu những việc như vậy trong khi ông đã dành phần lớn thời gian, công sức của mình để làm việc và nỗ lực? Ông để vợ ông có cuộc sống tốt nhất nhưng cuối cùng ông vẫn bị bỏ rơi với hàng loạt cáo buộc? Thực sự, sống tốt, sống lành là tốt hay không?",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/224/chung-minh-yeu-nhau-xong-roi.jpg",
      "id": "7"
    },
    {
      "nameItem": "Anh và Em",
      "price": "200000",
      "type": "tiengviet ",
      "describe":"Không trung thành với nguyên tác, với sự am hiểu sâu sắc về văn hoá Đông phương, thông tuệ triết lý nhà Phật, giáo sư John Vũ Nguyên Phong phóng tác lại Hoa sen trên tuyết khá thành công. Bằng lối kể gần gũi, chân tình để những trải nghiệm và cảm xúc của Alan Havey, người đã từng đứng ở đỉnh cao trong nấc thang địa vị cuộc đời được truyền tải, chạm đến hầu hết người đọc...",
      "image": "https://isach.info/images/story/cover/xom_cau_moi__nhat_linh.jpg",
      "id": "8"
    },
    {
      "nameItem": "The templars",
      "price": "249000",
      "type": "englishbook",
      "describe":"Đọc Hoa sen trên tuyết độc giả cũng sẽ hiểu thêm về đời sống nơi văn hóa tâm linh đang diễn ra ở vùng tuyết sơn Tây Tạng. Suốt hành trình của vị triệu phú, câu thần chú Om Mani Padme Hum xuất hiện hàng nghìn lần, ở khắp mọi nơi và đi sâu vào đời sống của người dân Tây Tạng. Om Mani Padme Hum là câu thần chú linh thiêng nhất của người Tây Tạng và nó có nghĩa là “Hoa sen trên tuyết”...",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/224/91u22jojcaL.jpg",
      "id": "9"
    },
    {
      "nameItem": "Sapiens",
      "price": "500000",
      "type": "englishbook",
      "describe":"Đường Mây Qua Xứ Tuyết (“The Way of the White Clouds”) ghi lại những điều Anagarika Govinda chứng kiến trong thời gian du hành ở Tây Tạng. Hành trình của tác giả diễn ra vào khoảng thập niên 30 đến thập niên 50 của thế kỷtrước, trước thời kỳ diễn biến chính trị phức tạp dẫn đến sự sáp nhập vào lãnh thổ nước Cộng hòa Nhân dân Trung Hoa như hiện nay...",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/217/1_szbg-vc.jpg",
      "id": "10"
    },
    {
      "nameItem": "You and me",
      "price": "230000",
      "type": "englishbook",
      "describe":"Thời điểm đó, một phần phía tây của Tây Tạng bị xem như nằm dưới sự kiểm soát của chính quyền thuộc địa Anh nên việc tác giả đi từ Sri Lanka sang Ấn Độ rồi thâm nhập phía tây Tây Tạng (tất cả đều là thuộc địa của Anh), giấy tờ thông hành đều do người Anh kiểm soát. Về phần sau của hành trình, tác giả đi sâu vào phần phía đông Tây Tạng vốn thuộc sự quản lý của chính quyền..",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/196/1_dnuy-no.jpg",
      "id": "11"
    },
    {
      "nameItem": "Memory garden",
      "price": "215000",
      "type": "englishbook",
      "describe":"Trên thực tế, từ thời cổ đại cho đến tận lúc bấy giờ, Tây Tạng vốn chỉ được xem như một vùng đất bí ẩn khép kín, một mắt xích trên con đường tơ lụa huyền thoại nên dù đã nhiều lần bị xâm chiếm, các chính quyền đô hộ tạm thời đều dần dà vùng đất này; do đó, nơi đây được đứng đầu bởi cố vấn tinh thần là các đức Lạt Ma mà cao nhất là Đạt Lai Lạt Ma...",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/194/5_2qsv-kp.jpg",
      "id": "12"
    },
    {
      "nameItem": "Blood and oil",
      "price": "150000",
      "type": "englishbook",
      "describe":"Những diễn biến chính trị từ thập niên 50 của thế kỷ trước trở về sau này, hẳn nhiên ít nhiều cũng có ảnh hưởng đến phong tục và đời sống tín ngưỡng của Tây Tạng. Song, nếu tìm hiểu và đặt tâm trí mình trở về với giai đoạn trước khinhững biến đổi phức tạp này diễn ra, người đọc sẽ cảm nhận rõ nét hơn về...",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/192/81SsiCIE5yL.jpg",
      "id": "13"
    },
    {
      "nameItem": "Our planet",
      "price": "699000",
      "type": "englishbook",
      "describe":"Ghi lại những điều Anagarika Govinda chứng kiến trong thời gian du hành ở Tây Tạng. Hành trình của tác giả diễn ra vào khoảng thập niên 30 đến thập niên 50 của thế kỷtrước, trước thời kỳ diễn biến chính trị phức tạp dẫn đến sự sáp nhập vào lãnh thổ nước Cộng hòa Nhân dân Trung Hoa như hiện nay. ..",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/119/Our_Planet_The_official_companion_to_the_ground-breaking_Netflix_original_Attenborough_series_with_a_special_foreword_by_David_Attenborough.jpg",
      "id": "14"
    },
    {
      "nameItem": "Hono Deus",
      "price": "259000",
      "type": "englishbook",
      "describe":"Thời điểm đó, một phần phía tây của Tây Tạng bị xem như nằm dưới sự kiểm soát của chính quyền thuộc địa Anh nên việc tác giả đi từ Sri Lanka sang Ấn Độ rồi thâm nhập phía tây Tây Tạng (tất cả đều là thuộc địa của Anh), giấy tờ thông hành đều do người Anh kiểm soát. Về phần sau của hành trình...",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/224/chung-minh-yeu-nhau-xong-roi.jpg",
      "id": "15"
    },
    {
      "nameItem": "Don't forget",
      "price": "190000",
      "type": "englishbook",
      "describe":"Những diễn biến chính trị từ thập niên 50 của thế kỷ trước trở về sau này, hẳn nhiên ít nhiều cũng có ảnh hưởng đến phong tục và đời sống tín ngưỡng của Tây Tạng. Song, nếu tìm hiểu và đặt tâm trí mình trở về với giai đoạn trước khinhững biến đổi phức tạp này diễn ra, người đọc sẽ cảm nhận rõ nét hơn về cái ...",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/224/xom-cau-moi.jpg",
      "id": "16"
    },
    {
      "nameItem": "Bộ băng keo cắt xanh lá",
      "price": "55000",
      "type": "hoccu",
      "describe":"Giá sản phẩm trên Tiki đã bao gồm thuế theo luật hiện hành. Bên cạnh đó, tuỳ vào loại sản phẩm, hình thức và địa chỉ giao hàng mà có thể phát sinh thêm chi phí khác như phí vận chuyển, phụ phí hàng cồng kềnh, thuế nhập khẩu (đối với đơn hàng giao từ nước ngoài có giá trị trên 1 triệu đồng)",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/220/BWM10420_01.jpg",
      "id": "17"
    },
    {
      "nameItem": "Bộ băng keo cắt xanh dương",
      "price": "35000",
      "type": "hoccu",
      "describe":"Bên Rặng Tuyết Sơn là quyển sách mới trong bộ sách khoa học tâm linh nổi tiếng của dịch giả Nguyên Phong. Khơi nguồn từ vùng núi Himalaya xa xôi và vùng đồng bằng Ấn Độ, Bên Rặng Tuyết Sơn mang đến cho bạn đọc những sự thật vĩ đại về tâm linh và vai trò của việc làm chủ tâm linh cũng như làm chủ số phận. Tác phẩm còn khơi dậy những giá trị cao đẹp như: Tính trung thực, trái tim bao dung, lòng trắc ẩn, sự thông thái, lòng tín ngưỡng và tình yêu bao la...",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/220/BWM10422_01.jpg",
      "id": "18"
    },
    {
      "nameItem": "Bộ băng keo cắt vàng",
      "price": "38000",
      "type": "hoccu",
      "describe":"Câu chuyện bắt đầu từ việc Satyakam đến thung lũng Saraswati để tầm sư học đạo. Nhưng không ngờ rằng, khi đến đây, thì vị đạo sư già đã chờ anh rồi, không những thế, ông còn nói đúng tên anh và biết anh đến gặp ông để làm gì dù rằng anh chưa hề xưng tên cũng như chưa nói mục đích của mình đến đây...",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/220/BWM10421_01.jpg",
      "id": "19"
    },
    {
      "nameItem": "Trống bô bi",
      "price": "92000",
      "type": "hoccu",
      "describe":"Dài học đầu tiên của Satyakam là quên đi thời gian. Việc này nghe qua tưởng chừng như đơn giản nhưng khi bắt đầu thực hiện lại không đơn giản chút nào. Cũng như việc lắng nghe những âm thanh của vũ trụ như tiếng lá rơi, tiếng gió thổi, tiếng nước reo cũng không dễ dàng thực hiện nếu trong lòng ta vẫn còn nhiều tạp âm...",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/222/dk81045_04-min_29b8ff898ae9454081e443056b424ec2_master.jpg",
      "id": "20"
    },
    {
      "nameItem": "Đồ chơi robot cún con",
      "price": "392000",
      "type": "hoccu",
      "describe":"Chúng ta sẽ được trải nghiệm những giây phút bình yên thông qua chuyến hành trình đi tìm chân lý của Satyakam dưới sự hướng dẫn của vị đạo sư trong dãy núi Tuyết Sơn để hiểu rõ hơn về sức mạnh vĩnh hằng của thế giới tâm linh cũng như khám phá chính tiếng nói nội tâm của bản thân mình...",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/222/image_244718_1_1751.jpg",
      "id": "21"
    },
    {
      "nameItem": "Rô bốt lăn lộn",
      "price": "369000",
      "type": "hoccu",
      "describe":"Cuộc đời Nora Seed tràn ngập khổ sở và nuối tiếc. Cô có nhiều khả năng nhưng lại ít thành tựu, và luôn cảm thấy mình đã làm mọi người xung quanh mình thất vọng. Thế rồi, vào lúc chuông điểm nửa đêm trong ngày cuối cùng còn trên thế gian, Nora thấy mình xuất hiện ở Thư viện nửa đêm...",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/220/vt2028109org_1_.jpg",
      "id": "22"
    },
    {
      "nameItem": "Xe vượt địa hình ",
      "price": "459000",
      "type": "hoccu",
      "describe":"Matt Haig (sinh năm 1975) là một nhà báo và tiểu thuyết gia người Anh. Các tác phẩm của ông bao gồm cả hư cấu và phi hư cấu, viết cho đối tượng từ trẻ em tới người lớn, đã bán được hơn ba triệu bản trên toàn thế giới và được dịch ra hơn bốn mươi ngôn ngữ khác nhau. Ông đã ba lần được đề cử cho giải thưởng văn học Carnegie Medal. Haig hiện sống tại Brighton (Sussex, Anh) cùng vợ, hai con và một chú chó....",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/220/vt1918-or_1_.jpg",
      "id": "23"
    },
    {
      "nameItem": "Tomica xe mẫu ",
      "price": "99000",
      "type": "hoccu",
      "describe":"Là sản phẩm đồ chơi cho trẻ em nhằm phát triển trí tuệ, nâng cao nhận thức về lắp ráp và logic...",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/210/1_zoxb-x6.JPG",
      "id": "23"
    },
    {
      "nameItem": "Rubik 3*3",
      "price": "59000",
      "type": "dochoi",
      "describe":"Là sản phầm làm tự nhựa thiên nhiên đảm bảo sức khỏe cho trẻ em và không chất độc hại. Sơn được làm từ sơn cao cấp đề đảm bảo thẩm mỹ.",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/136/rubik-mini-3-3.jpg",
      "id": "24"
    },
    {
      "nameItem": "Rubik 2*2",
      "price": "65000",
      "type": "dochoi",
      "describe":"Rubik 2*2 với mục đích cho trẻ làm quen với logic và nhằm phát triển tư duy của trẻ, là món đồ chơi mà trẻ có thể thử sức đơn giản.",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/136/rubik-do-choi-5-5.jpg",
      "id": "24"
    },
    {
      "nameItem": "Rubik 4*4",
      "price": "165000",
      "type": "dochoi",
      "describe":"Rubik 4*4 là rubik có độ khó cao, có kèm theo hướng dẫn giải. Bạn có thể thử sức nhiều hơn, khó hơn với sản phẩm này.",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/136/rubik-62-62.jpg",
      "id": "25"
    },
    {
      "nameItem": "Trò chơi in tem cho bé",
      "price": "105000",
      "type": "dochoi",
      "describe":"Trò chơi in tem cho bé với mục đích giải trí và trang trí, nhằm tăng sự sáng tạo và khả năng thẩm mỹ.",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/192/106314253_000_583c6015a86c4fbc89bda5e2b2152c62_a13a1cd741b04483b0dc3d701d5ba1d1_master.jpg",
      "id": "27"
    },
    {
      "nameItem": "Búp bê thời trang",
      "price": "239000",
      "type": "dochoi",
      "describe":"Búp bê thời trang có bao gồm nhiều áo quần đi kèm và các phụ kiện khác, giúp bé thoải mái thay đổi và trang trí.",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/192/1057366-b3r2rup-be-thoi-trang-hoan-doi-steffi-love-swap-4-ass.jpg",
      "id": "28"
    },
    {
      "nameItem": "Bộ rút thanh gỗ",
      "price": "245000",
      "type": "dochoi",
      "describe":"Bộ rút thanh gỗ đặc biệt, làm từ gỗ thơm và sơn bóng bền, đẹp. Không độc hại.",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/209/image_229768.jpg",
      "id": "28"
    },
    {
      "nameItem": "Bộ trò chơi tiếng việt",
      "price": "175000",
      "type": "dochoi",
      "describe":"Thư viện nửa đêm là cuốn tiểu thuyết thứ bảy của Matt Haig, ra mắt vào quý III năm 2020 và ngay lập tức lọt vào danh sách sách bán chạy của The New York Times. Sách đã được mua bản quyền chuyển thể thành phim.",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/209/image_188875.jpg",
      "id": "29"
    },
    {
      "nameItem": "Xếp hình bông hoa",
      "price": "105000",
      "type": "dochoi",
      "describe":"Cô gái Sophie Hatter đang sống và làm việc yên ổn trong cửa hiệu bán mũ của bố mẹ ở Ingary, xứ sở của những đôi ủng bảy lý và áo tàng hình thì bỗng một ngày, mụ phù thuỷ xứ Waste xuất hiện biến cô thành bà già xấu xí. Quyết tâm giải cứu bản thân mình, Sophie đi tới lâu đài bay tìm kiếm sự giúp đỡ của Pháp sư Howl ...",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/205/1_cvo8-m2.jpg",
      "id": "30"
    },
    {
      "nameItem": "Gép nam châm",
      "price": "625000",
      "type": "dochoi",
      "describe":"Sophie ngậm ngón tay bị bỏng nhẹ và lấy tay kia nhặt những lát thịt ba chỉ xông khói rơi trên váy, mắt chằm chằm nhìn Calcifer. Lão đang quật từ bên này sang bên kia lò sưởi. Những bộ mặt xanh lơ của lão gần như trắng bệch.",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/205/1_7mux-l1.jpg",
      "id": "31"
    },
    {
      "nameItem": "Cờ ô quan",
      "price": "495000",
      "type": "dochoi",
      "describe":"Có cái gì đó quét qua trên đầu với một phát nổ và tiếng đùng làm rung chuyển mọi thứ trong phòng. Một cái gì đó thứ hai theo sau, với tiếng rống dài chói tai. Calcifer rung lên gần như xanh đen, và da Sophie xèo xèo vì tàn lửa từ phép thần thông đó…",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/205/1_o8e1-qg.jpg",
      "id": "32"
    },
    {
      "nameItem": "Lịch 52 tuần-Thịnh vượng",
      "price": "200000",
      "type": "phukien",
      "describe":"Tại thành Zanzib ở vương quốc Rashpuht, phía Nam của Ingary, có một người buôn thảm trẻ tuổi tên Abdullah ngày ngày đắm chìm trong những mộng tưởng hoang đường. Tuy chẳng giàu có nhưng anh rất bằng lòng với cuộc sống của mình, cho tới ngày anh được một lữ khách phương xa bán cho một tấm thảm mầu nhiệm.",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/222/viet_nam_thinh_vuong.png",
      "id": "33"
    },
    {
      "nameItem": "Lịch 52 tuần-Lộc phat",
      "price": "210000",
      "type": "phukien",
      "describe":"Hằng đêm, tấm thảm đưa anh tới một khu vườn đẹp mê hoặc, nơi anh gặp gỡ và đem lòng yêu nàng công chúa Hoa Đêm khả á. Một đêm nọ, nàng lại bị ma thần cướp đi ngay trước mắt anh. Với tấm thảm thần giúp sức và sự lanh trí của bản thân, Abdullah khăn gói lên đường đi giải cứu cô gái của lòng mì",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/222/loc_phat_bon_mua.png",
      "id": "34"
    },
    {
      "nameItem": "Lịch 52 tuần-Phát tài",
      "price": "220000",
      "type": "phukien",
      "describe":"Phần tiếp theo của Lâu đài bay của pháp sư Howl không hề kém cạnh phần đầu. Với khiếu hài hước kỳ lạ và những tình tiết bí ẩn, Jones đã thành công trong việc tạo nên cho cuốn sách một không khí căng thẳng mà dí dỏm, và lần nữa chứng minh rằng mọi sự không phải lúc nào cũng như ta tưởng.",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/222/Untitled.png",
      "id": "35"
    },
    {
      "nameItem": "Đồng hồ để bàn YX8",
      "price": "198000",
      "type": "phukien",
      "describe":"Cô gái Sophie Hatter đang sống và làm việc yên ổn trong cửa hiệu bán mũ của bố mẹ ở Ingary, xứ sở của những đôi ủng bảy lý và áo tàng hình thì bỗng một ngày, mụ phù thuỷ xứ Waste xuất hiện biến cô thành bà già xấu xí. Quyết tâm giải cứu bản thân mình, Sophie đi tới lâu đài bay tìm kiếm sự giúp đỡ của Pháp sư Howl",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/221/8363.png",
      "id": "36"
    },
    {
      "nameItem": "Bìa lò xo",
      "price": "29000",
      "type": "phukien",
      "describe":"Sophie ngậm ngón tay bị bỏng nhẹ và lấy tay kia nhặt những lát thịt ba chỉ xông khói rơi trên váy, mắt chằm chằm nhìn Calcifer. Lão đang quật từ bên này sang bên kia lò sưởi. Những bộ mặt xanh lơ của lão gần như trắng bệch. Trong khoảnh khắc, lão có vô số những con mắt da cam, rồi khoảnh khắc sau đó đã có hàng dãy những con mắt bạc sáng như sao",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/221/tui-vang-phu-quy_7rg1-jx.png",
      "id": "37"
    },
    {
      "nameItem": "Bìa lò xo Giữa Gằn",
      "price": "44000",
      "type": "phukien",
      "describe":"Có cái gì đó quét qua trên đầu với một phát nổ và tiếng đùng làm rung chuyển mọi thứ trong phòng. Một cái gì đó thứ hai theo sau, với tiếng rống dài chói tai. Calcifer rung lên gần như xanh đen, và da Sophie xèo xèo vì tàn lửa từ phép thần thông đó…",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/221/mau_xanh_thinh_vuong.png",
      "id": "38"
    },
    {
      "nameItem": "Lịch Siêu Đại",
      "price": "240000",
      "type": "phukien",
      "describe":"Cuộc đời Nora Seed tràn ngập khổ sở và nuối tiếc. Cô có nhiều khả năng nhưng lại ít thành tựu, và luôn cảm thấy mình đã làm mọi người xung quanh mình thất vọng. Thế rồi, vào lúc chuông điểm nửa đêm trong ngày cuối cùng còn trên thế gian, Nora thấy mình xuất hiện ở Thư viện nửa đêm ",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/221/lich_sac_hoa.png",
      "id": "39"
    },
    {
      "nameItem": "Lịch cực đại",
      "price": "320000",
      "type": "phukien",
      "describe":"Tác giả này đã có một số cuốn xuất bản ở VN như Những điều giữ tôi còn sống (Reasons to Stay Alive, Bloom Books/Thế Giới, 2019), Ghi chép về một hành tinh âu lo (Notes on a Nervous Planet, Bloom Books/Thế Giới, 2020), Sự thật về 100 thất bại thương hiệu lớn nhất của mọi thời đại",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/221/tai_loc_nhu_y.png",
      "id": "40"
    },
    {
      "nameItem": "Làn sóng xanh 2",
      "price": "2000",
      "type": "bangdia",
      "describe":"Là hậu duệ của Cotton Mather, kẻ châm ngòi cho các Phiên tòa xét xử phù thủy Salem thế kỷ 17, Samantha Mather lập tức bị cô lập khi chuyển nhà tới thị trấn Salem. Cô trở thành mục tiêu bắt nạt tại trường mới, đứng đầu là hội Hậu duệ hùng mạnh của những phù thuỷ đã bị buộc tội và sát hại.",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/224/lsx_21.jpg",
      "id": "41"
    },
    {
      "nameItem": "Danh nhân đất Việt1",
      "price": "6000",
      "type": "bangdia",
      "describe":"Khi những sự việc kỳ lạ và ma quái liên tục xảy đến, Sam nhận ra mình đang phải đối mặt với một lời nguyền hiểm ác từ nhiều thế kỷ trước, lời nguyền trói buộc tất cả các gia tộc liên đới tới Phiên tòa xét xử phù thủy. Sam buộc phải bắt tay với một hồn ma và tìm cách hợp tác với những kẻ bắt nạt mình, để ngăn chặn chu kỳ chết chóc vẫn đang tiếp diễn, kể từ khi phù thuỷ đầu tiên bị treo cổ.",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/224/DANH_NHAN_1.jpg",
      "id": "42"
    },
    {
      "nameItem": "CT18-Cổ tích VN",
      "price": "5000",
      "type": "bangdia",
      "describe":"Nếu có một vùng đất cần khắc sâu bài học thương đau từ quá khứ, thì đó hẳn phải là Salem. Nhưng lịch sử sắp lặp lại, có thể còn kinh hoàng hơn trước.",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/224/CT_18_1.jpg",
      "id": "43"
    },
    {
      "nameItem": "CT16-Cổ tích VN16",
      "price": "5000",
      "type": "bangdia",
      "describe":"Sự lãng mạn từ cuộc tình tay ba huyền bí, pha trộn sự rùng rợn từ những sự kiện đen tối có thật trong lịch sử nước Mỹ, cùng với nhiều xung đột kịch tính ở thời hiện đại đã làm nên cuốn tiểu thuyết bán chạy số 1 New York Times",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/224/CT_16_1.jpg",
      "id": "44"
    },
    {
      "nameItem": "CT15-Cổ tích VN 15",
      "price": "5000",
      "type": "bangdia",
      "describe":"Cuốn sách này sẽ giữ bạn yên vị một chỗ, cuốn vào câu chuyện của những phù thuỷ, hồn ma, một lời nguyền cổ xưa và một tình yêu lãng mạn. Nó thật đẹp. Ám ảnh. Các nhân vật sống động và chân thực. Tôi không có cách nào đặt nó xuống.",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/224/CT_15_1.jpg",
      "id": "45"
    },
    {
      "nameItem": "Cổ tích VN 14",
      "price": "5000",
      "type": "bangdia",
      "describe":"Vì một tổn thương tâm lý, Kokoro từ chối đến trường, nhốt mình trong phòng. Những ngày tháng nhàm chán và buồn bã lặng lẽ trôi qua, cho đến một hôm, cô bé phát hiện tấm gương trong phòng mình phát sáng. Bước qua tấm gương, Kokoro nhận ra mình đang ở trong một tòa lâu đài lộng lẫy, cùng sáu người bạn chung hoàn cảnh.",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/224/CT_14_1.jpg",
      "id": "46"
    },
    {
      "nameItem": "CT12-Cổ tích VN12",
      "price": "5000",
      "type": "bangdia",
      "describe":"Họ được tập hợp tại đó bởi ai và với mục đích gì? Bảy đứa trẻ cô độc buộc phải dấn bước vào một cuộc phiêu lưu kỳ lạ, trước khi đáp án cuối cùng mở ra, gây sững sờ và xúc động tột cùng.",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/224/CT_12_1.jpg",
      "id": "47"
    },
    {
      "nameItem": "CT11-Cổ tích VN 11",
      "price": "5000",
      "type": "bangdia",
      "describe":"Tsujimura Mizuki sinh tại tỉnh Yamanashi, Nhật Bản và là một nhà văn nổi tiếng, chủ nhân của rất nhiều giải thưởng văn học. Năm 2004, Tsujimura Mizuki đạt giải Mephisto với tác phẩm ra mắt Khu học xá bị lãng quên (tạm dịch). Năm 2011, cô tiếp tục đạt giải tác giả mới, giải thưởng Yoshikawaeijibungaku với tác phẩm Kết nối (tạm dịch).",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/224/CT_11_1.jpg",
      "id": "48"
    },
    {
      "nameItem": "Thiên Hành Yêu Chỉ",
      "price": "72000",
      "type": "uudai",
      "describe":"Một nửa đích thực được tác giả John Marrs xuất bản lần đầu năm 2016 dưới tên Một ngàn vụ nổ nhỏ. Năm 2017 cuốn sách được Penguin Random House mua bản quyền và phát hành dưới ấn hiệu Del Rey, và bán được hơn 200.000 bản. Năm 2018, cuốn sách được tập san The Wall Street đánh giá là một trong những tiểu thuyết khoa học viễn tưởng hay nhất năm. Tính tới tháng 11 năm 2020,",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/224/thien-hanh-yeu-chi-tb-2021.jpg",
      "id": "49"
    },
    {
      "nameItem": "Cậu bé cưỡi rồng",
      "price": "15000",
      "type": "uudai",
      "describe":"Bấy lâu nay, kiếm tìm một người tri kỷ, mảnh ghép hoàn hảo của cuộc đời ta vốn không phải điều dễ dàng. Nhưng giờ đây, nhờ một khám phá khoa học mới, chỉ một xét nghiệm gene đơn giản đã có thể đảm bảo bất cứ ai cũng có thể tìm thấy một nửa đích thực, mà không phải trải qua những cuộc tình tan vỡ với đối tượng không phù hợp. Hàng triệu người trên thế giới đã chọn cách này, trong đó có Mandy, Christopher, Jade, Nick và Ellie",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/224/z3000135356515_42602bc1c637723ff36b1a511a713cf5_u4u6-ig.jpg",
      "id": "50"
    },
    {
      "nameItem": "Tàu tốc hành Bắc Cực",
      "price": "15000",
      "type": "uudai",
      "describe":"Tất thảy đều tin rằng mình đã tìm được tình yêu vĩ đại, người có thể đồng hành cùng họ đến cuối cuộc đời. Nhưng liệu mọi chuyện có đơn giản như vậy, khi ngay cả những người tri kỷ cũng có thể cất giấu những bí mật kinh hoàng Duyên dáng và độc đáo,",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/224/z3000135350548_31084bc290e6a3e2d3555ba8a3c42bd6.jpg",
      "id": "51"
    },
    {
      "nameItem": "Người tình tổng thống",
      "price": "15000",
      "type": "uudai",
      "describe":"Không giống bất cứ cuốn tiểu thuyết tâm lý ly kỳ nào khác, Một nửa đích thực hệt như một tập phim dài thuộc bộ phim Black Mirror. Marrs đã viết tài tình đến độ ta bất giác cho rằng mọi thứ có thể xảy ra ngoài đời thật lắm chứ",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/224/z3000136331709_c611ba775141926e086363a418e07cdd.jpg",
      "id": "52"
    },
    {
      "nameItem": "Cô bạn gia sư",
      "price": "15000",
      "type": "uudai",
      "describe":"John Marrs là nhà báo tự do ở Luân Đôn, Anh. Ông đã dành hai mươi năm qua để phỏng vấn người nổi tiếng trong giới truyền hình, điện ảnh và âm nhạc cho các tờ báo và tạp chí quốc gia. Ông đã sáng tác cho nhiều đơn vị xuất bản bao gồm Guardian’s Guide và Guardian Online, Total Film, Huffington Post, Empire, Q, GT, Independent, S Magazine và Company.",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/224/z3000136350444_167d74af89f4ade6be5c29de5b7f3653.jpg",
      "id": "53"
    },
    {
      "nameItem": "Chồng của mẹ tôi",
      "price": "10000",
      "type": "uudai",
      "describe":"John Marrs là nhà báo tự do ở Luân Đôn, Anh. Ông đã dành hai mươi năm qua để phỏng vấn người nổi tiếng trong giới truyền hình, điện ảnh và âm nhạc cho các tờ báo và tạp chí quốc gia. Ông đã sáng tác cho nhiều đơn vị xuất bản bao gồm Guardian’s Guide và Guardian Online, Total Film, Huffington Post, Empire, Q, GT, Independent, S Magazine và Company.",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/224/z3000136382448_6b6a75f1bd1c7c60e3b2369a3579241f.jpg",
      "id": "54"
    },
    {
      "nameItem": "Vô tình",
      "price": "10000",
      "type": "uudai",
      "describe":"John Marrs là nhà báo tự do ở Luân Đôn, Anh. Ông đã dành hai mươi năm qua để phỏng vấn người nổi tiếng trong giới truyền hình, điện ảnh và âm nhạc cho các tờ báo và tạp chí quốc gia. Ông đã sáng tác cho nhiều đơn vị xuất bản bao gồm Guardian’s Guide và Guardian Online, Total Film, Huffington Post, Empire, Q, GT, Independent, S Magazine và Company.",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/224/z3000136389738_db81ac3884815cdb6cd294624ea86bd7.jpg",
      "id": "55"
    },
    {
      "nameItem": "Dãy núi",
      "price": "10000",
      "type": "uudai",
      "describe":"John Marrs là nhà báo tự do ở Luân Đôn, Anh. Ông đã dành hai mươi năm qua để phỏng vấn người nổi tiếng trong giới truyền hình, điện ảnh và âm nhạc cho các tờ báo và tạp chí quốc gia. Ông đã sáng tác cho nhiều đơn vị xuất bản bao gồm Guardian’s Guide và Guardian Online, Total Film, Huffington Post, Empire, Q, GT, Independent, S Magazine và Company.",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/224/z3000135316828_1013908f7874ba09b1c8f7ac6643124b.jpg",
      "id": "56"
    },
    {
      "nameItem": " Quang Trung",
      "price": "88000",
      "type": "outlet",
      "describe":"John Marrs là nhà báo tự do ở Luân Đôn, Anh. Ông đã dành hai mươi năm qua để phỏng vấn người nổi tiếng trong giới truyền hình, điện ảnh và âm nhạc cho các tờ báo và tạp chí quốc gia. Ông đã sáng tác cho nhiều đơn vị xuất bản bao gồm Guardian’s Guide và Guardian Online, Total Film, Huffington Post, Empire, Q, GT, Independent, S Magazine và Company.",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/217/1_hvo9-w8.jpg",
      "id": "57"
    },
    {
      "nameItem": " Nguyễn Trung Trực",
      "price": "49000",
      "type": "outlet",
      "describe":"John Marrs là nhà báo tự do ở Luân Đôn, Anh. Ông đã dành hai mươi năm qua để phỏng vấn người nổi tiếng trong giới truyền hình, điện ảnh và âm nhạc cho các tờ báo và tạp chí quốc gia. Ông đã sáng tác cho nhiều đơn vị xuất bản bao gồm Guardian’s Guide và Guardian Online, Total Film, Huffington Post, Empire, Q, GT, Independent, S Magazine và Company.",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/217/1_9p7x-8f.jpg",
      "id": "58"
    },
    {
      "nameItem": " Phan Thanh Giản",
      "price": "68000",
      "type": "outlet",
      "describe":"John Marrs là nhà báo tự do ở Luân Đôn, Anh. Ông đã dành hai mươi năm qua để phỏng vấn người nổi tiếng trong giới truyền hình, điện ảnh và âm nhạc cho các tờ báo và tạp chí quốc gia. Ông đã sáng tác cho nhiều đơn vị xuất bản bao gồm Guardian’s Guide và Guardian Online, Total Film, Huffington Post, Empire, Q, GT, Independent, S Magazine và Company.",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/217/1_b9pr-lt.jpg",
      "id": "59"
    },
    {
      "nameItem": "Trai Thừa",
      "price": "62000",
      "type": "outlet",
      "describe":"John Marrs là nhà báo tự do ở Luân Đôn, Anh. Ông đã dành hai mươi năm qua để phỏng vấn người nổi tiếng trong giới truyền hình, điện ảnh và âm nhạc cho các tờ báo và tạp chí quốc gia. Ông đã sáng tác cho nhiều đơn vị xuất bản bao gồm Guardian’s Guide và Guardian Online, Total Film, Huffington Post, Empire, Q, GT, Independent, S Magazine và Company.",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/217/1_oj62-fe.jpg",
      "id": "60"
    },
    {
      "nameItem": "Hình thành thói quen sông độc lập cho trẻ",
      "price": "22000",
      "type": "outlet",
      "describe":"John Marrs là nhà báo tự do ở Luân Đôn, Anh. Ông đã dành hai mươi năm qua để phỏng vấn người nổi tiếng trong giới truyền hình, điện ảnh và âm nhạc cho các tờ báo và tạp chí quốc gia. Ông đã sáng tác cho nhiều đơn vị xuất bản bao gồm Guardian’s Guide và Guardian Online, Total Film, Huffington Post, Empire, Q, GT, Independent, S Magazine và Company.",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/217/1_09e5-dj.jpg",
      "id": "61"
    },
    {
      "nameItem": "Nho giao  Kinh Kỳ",
      "price": "34000",
      "type": "outlet",
      "describe":"John Marrs là nhà báo tự do ở Luân Đôn, Anh. Ông đã dành hai mươi năm qua để phỏng vấn người nổi tiếng trong giới truyền hình, điện ảnh và âm nhạc cho các tờ báo và tạp chí quốc gia. Ông đã sáng tác cho nhiều đơn vị xuất bản bao gồm Guardian’s Guide và Guardian Online, Total Film, Huffington Post, Empire, Q, GT, Independent, S Magazine và Company.",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/217/1_ug89-r2.jpg",
      "id": "62"
    },
    {
      "nameItem": "lê Hoàn ",
      "price": "5000",
      "type": "outlet",
      "describe":"John Marrs là nhà báo tự do ở Luân Đôn, Anh. Ông đã dành hai mươi năm qua để phỏng vấn người nổi tiếng trong giới truyền hình, điện ảnh và âm nhạc cho các tờ báo và tạp chí quốc gia. Ông đã sáng tác cho nhiều đơn vị xuất bản bao gồm Guardian’s Guide và Guardian Online, Total Film, Huffington Post, Empire, Q, GT, Independent, S Magazine và Company.",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/217/1_qi05-1m.jpg",
      "id": "63"
    },
    {
      "nameItem": "Hậu Ngô Vương",
      "price": "5000",
      "type": "outlet",
      "describe":"John Marrs là nhà báo tự do ở Luân Đôn, Anh. Ông đã dành hai mươi năm qua để phỏng vấn người nổi tiếng trong giới truyền hình, điện ảnh và âm nhạc cho các tờ báo và tạp chí quốc gia. Ông đã sáng tác cho nhiều đơn vị xuất bản bao gồm Guardian’s Guide và Guardian Online, Total Film, Huffington Post, Empire, Q, GT, Independent, S Magazine và Company.",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/217/1_c71b-m3.jpg",
      "id": "64"
    },
    {
      "nameItem": "Cô độc nên thơ",
      "price": "80000",
      "type": "spnb",
      "describe":"John Marrs là nhà báo tự do ở Luân Đôn, Anh. Ông đã dành hai mươi năm qua để phỏng vấn người nổi tiếng trong giới truyền hình, điện ảnh và âm nhạc cho các tờ báo và tạp chí quốc gia. Ông đã sáng tác cho nhiều đơn vị xuất bản bao gồm Guardian’s Guide và Guardian Online, Total Film, Huffington Post, Empire, Q, GT, Independent, S Magazine và Company.",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/223/yeu_sach_cua_antigone.jpg",
      "id": "66"
    },
    {
      "nameItem": "Khai nguyên rồng tiên",
      "price": "50000",
      "type": "spnb",
      "describe":"John Marrs là nhà báo tự do ở Luân Đôn, Anh. Ông đã dành hai mươi năm qua để phỏng vấn người nổi tiếng trong giới truyền hình, điện ảnh và âm nhạc cho các tờ báo và tạp chí quốc gia. Ông đã sáng tác cho nhiều đơn vị xuất bản bao gồm Guardian’s Guide và Guardian Online, Total Film, Huffington Post, Empire, Q, GT, Independent, S Magazine và Company.",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/222/khai-nguyen-rong-tien.jpg",
      "id": "67"
    },
    {
      "nameItem": "Tôi tự học",
      "price": "60000",
      "type": "spnb",
      "describe":"John Marrs là nhà báo tự do ở Luân Đôn, Anh. Ông đã dành hai mươi năm qua để phỏng vấn người nổi tiếng trong giới truyền hình, điện ảnh và âm nhạc cho các tờ báo và tạp chí quốc gia. Ông đã sáng tác cho nhiều đơn vị xuất bản bao gồm Guardian’s Guide và Guardian Online, Total Film, Huffington Post, Empire, Q, GT, Independent, S Magazine và Company.",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/222/toi-tu-hoc-db.jpg",
      "id": "68"
    },
    {
      "nameItem": "Nghìn lẻ một đêm",
      "price": "120000",
      "type": "spnb",
      "describe":"John Marrs là nhà báo tự do ở Luân Đôn, Anh. Ông đã dành hai mươi năm qua để phỏng vấn người nổi tiếng trong giới truyền hình, điện ảnh và âm nhạc cho các tờ báo và tạp chí quốc gia. Ông đã sáng tác cho nhiều đơn vị xuất bản bao gồm Guardian’s Guide và Guardian Online, Total Film, Huffington Post, Empire, Q, GT, Independent, S Magazine và Company.",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/223/Ngh%C3%ACn_l%E1%BA%BB_m%E1%BB%99t_%C4%91%C3%AAm.jpg",
      "id": "69"
    },
    {
      "nameItem": "Một ví dụ xoàng",
      "price": "20000",
      "type": "spnb",
      "describe":"John Marrs là nhà báo tự do ở Luân Đôn, Anh. Ông đã dành hai mươi năm qua để phỏng vấn người nổi tiếng trong giới truyền hình, điện ảnh và âm nhạc cho các tờ báo và tạp chí quốc gia. Ông đã sáng tác cho nhiều đơn vị xuất bản bao gồm Guardian’s Guide và Guardian Online, Total Film, Huffington Post, Empire, Q, GT, Independent, S Magazine và Company.",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/222/mot-vi-du-xoang.jpg",
      "id": "70"
    },
    {
      "nameItem": "Nắng thô tang",
      "price": "15000",
      "type": "spnb",
      "describe":"John Marrs là nhà báo tự do ở Luân Đôn, Anh. Ông đã dành hai mươi năm qua để phỏng vấn người nổi tiếng trong giới truyền hình, điện ảnh và âm nhạc cho các tờ báo và tạp chí quốc gia. Ông đã sáng tác cho nhiều đơn vị xuất bản bao gồm Guardian’s Guide và Guardian Online, Total Film, Huffington Post, Empire, Q, GT, Independent, S Magazine và Company.",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/222/nang-tho-tang.jpg",
      "id": "71"
    },
    {
      "nameItem": "Phật trong hẻm",
      "price": "90000",
      "type": "spnb",
      "describe":"John Marrs là nhà báo tự do ở Luân Đôn, Anh. Ông đã dành hai mươi năm qua để phỏng vấn người nổi tiếng trong giới truyền hình, điện ảnh và âm nhạc cho các tờ báo và tạp chí quốc gia. Ông đã sáng tác cho nhiều đơn vị xuất bản bao gồm Guardian’s Guide và Guardian Online, Total Film, Huffington Post, Empire, Q, GT, Independent, S Magazine và Company.",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/221/phat-trong-hem-nho.jpg",
      "id": "72"
    },
    {
      "nameItem": "Đại dương đen",
      "price": "250000",
      "type": "spnb",
      "describe":"John Marrs là nhà báo tự do ở Luân Đôn, Anh. Ông đã dành hai mươi năm qua để phỏng vấn người nổi tiếng trong giới truyền hình, điện ảnh và âm nhạc cho các tờ báo và tạp chí quốc gia. Ông đã sáng tác cho nhiều đơn vị xuất bản bao gồm Guardian’s Guide và Guardian Online, Total Film, Huffington Post, Empire, Q, GT, Independent, S Magazine và Company.",
      "image": "https://nhasachphuongnam.com/images/thumbnails/213/213/detailed/221/dai-duong-den.jpg",
      "id": "73"
    }
  ]